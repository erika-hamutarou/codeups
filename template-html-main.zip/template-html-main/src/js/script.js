jQuery(function($) { // この中であればWordpressでも「$」が使用可能になる


});
//------------------------------------------------
//  ハンバーガーメニューの設定
//------------------------------------------------
// ハンバーガーメニューをクリック時、「三」マークから「✖️」マークに変形するアクション
$(".openbtn").click(function() {
    $(this).toggleClass('active');
    $('.nav__sp').fadeToggle(300);
});

//ハンバーガーメニューをクリック時、メニュー一覧を表示
$(".openbtn").click(function() {
    $(".nav__sp").toggleClass('is-active');
});


//ハンバーガーメニュー内のメニューをクリック時、メニュー一覧を閉じる
$(".nav__sp--menu, .nav__sp--subMenu").click(function() {
    $(".nav__sp").removeClass('is-active');
    $(".openbtn").removeClass('active');
});

// ----------------------------------------------
//  メインビジュアルのスライドショーの設定
//------------------------------------------------
$(function() {
    $(".slider").slick({
        arrows: false,
        autoplay: true,
        autoplaySpeed: 2000,
        centerMode: true,
        dots: false,
        fade: true,
        slidesToShow: 1,
        speed: 2000,
    });
});
// ----------------------------------------------
//  キャンペーンセクションのスライドショーの設定
//------------------------------------------------


const swiper = new Swiper(".swiper", {
    loop: true,
    speed: 3000,
    slidesPerView: 'auto',
    autoplay: {
        delay: 1500,
        disableOnInteraction: false,
    },
    breakpoints: {
        768: {
            spaceBetween: 40
        }
    },
    navigation: {
        nextEl: '.campaign__button--next',
        prevEl: '.campaign__button--prev',
        clickable: true,
    }
});

//------------------------------------------------
//  TOPへ戻るボタンの設定
//------------------------------------------------

$(function() {
    const toTopButton = $(".js-to-top");
    // let isAnimating = false;

    toTopButton.hide();

    $(window).scroll(function() {
        if ($(this).scrollTop() > 400) {
            toTopButton.fadeIn();
        } else {
            toTopButton.fadeOut();
        }
    });

    toTopButton.click(function() {
        $("body,html").animate({
                scrollTop: 0,
            },
            500
        );
        return false;
    });

});


//------------------------------------------------
//  画像のアニメーション
//------------------------------------------------
// //要素の取得とスピードの設定
// var box = $('.js-colorbox'),
//     speed = 700;

// //.colorboxの付いた全ての要素に対して下記の処理を行う
// box.each(function() {
//     $(this).append('<div class="color"></div>')
//     var color = $(this).find($('.color')),
//         image = $(this).find('img');
//     var counter = 0;

//     image.css('opacity', '0');
//     color.css('width', '0%');
//     //inviewを使って背景色が画面に現れたら処理をする
//     color.on('inview', function() {
//         if (counter == 0) {
//             $(this).delay(200).animate({ 'width': '100%' }, speed, function() {
//                 image.css('opacity', '1');
//                 $(this).css({ 'left': '0', 'right': 'auto' });
//                 $(this).animate({ 'width': '0%' }, speed);
//             })
//             counter = 1;
//         }
//     });
// });

// $(function() {
//     var box = $('.js-colorbox');
//     var speed = 700;
//     box.each(function() {
//         $(this).append('<div class="color"></div>');
//         var color = $(this).find($('.color')),
//             image = $(this).find('img');
//         var executed = false; // executedフラグを追加

//         image.css('opacity', '0');
//         color.css('width', '0%');

//         // inviewイベントを使用して背景色が画面に現れたら処理をする
//         color.on('inview', function() {
//             if (!executed) {
//                 // アニメーションが未実行の場合のみ実行
//                 $(this).delay(200).animate({
//                     width: '100%'
//                 }, speed, function() {
//                     image.css('opacity', '1');
//                     $(this).css({
//                         left: '0',
//                         right: 'auto'
//                     });
//                     $(this).animate({
//                         width: '0%'
//                     }, speed);
//                 });
//                 executed = true; // アニメーション実行後にフラグを更新
//             }
//         });
//     });
// });

$(function() {
    var box = $('.js-colorbox');
    var speed = 700;

    box.each(function() {
        $(this).append('<div class="color"></div>');
        var color = $(this).find('.color'),
            image = $(this).find('img');
        var executed = false;

        image.css('opacity', '0');
        color.css('width', '0%');

        color.inView().on('inview', function() {
            if (!executed) {
                $(this).delay(200).animate({
                    width: '100%'
                }, speed, function() {
                    image.css('opacity', '1');
                    $(this).css({
                        left: '0',
                        right: 'auto'
                    });
                    $(this).animate({
                        width: '0%'
                    }, speed);
                });
                executed = true;
            }
        });
    });
});